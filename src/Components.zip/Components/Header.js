import React from 'react'
import './Header.css';

function Header() {
  return (
    <div>
      <ul className='main_header'>
        <li>Home</li>
        <li>Contact</li>
        <li>Services</li>
      </ul>
    </div>
  )
}

export default Header