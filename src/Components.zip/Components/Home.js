import React from 'react'
import image1 from './demo.jpg';
import './Home.css'
function Home() {
  return (
    <div>
      <img src={image1} className='home_img'></img>
    </div>
  )
}

export default Home